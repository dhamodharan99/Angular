Social login project:

1. npm install bootstrap@4 jquery --save
10. Modify angular.json :
"styles": [
  "src/styles.css",
  "node_modules/bootstrap/dist/css/bootstrap.min.css"
]
"scripts": [
  "node_modules/jquery/dist/jquery.min.js",
  "node_modules/bootstrap/dist/js/bootstrap.min.js"
]
2. npm install ng4-social-login --save
3. https://console.developers.google.com/
client id: 46088229201-ijh3qncb9o5m0d7pvnlg72joamvcur79.apps.googleusercontent.com
client screct: CkQCB1yr83rd_U1zUACghOni
4. https://developers.facebook.com/
APP ID: 158902985229718   App Secret: 3550e2fe81afb21dc4ea1b6139057f04
5. http://developer.linkedin.com/
Client ID: 781u4zhql2c8ge
client screct: UsBDaLtyQqFMOrBi
6. npm install --save rxjs-compat
7. npm run postinstall
