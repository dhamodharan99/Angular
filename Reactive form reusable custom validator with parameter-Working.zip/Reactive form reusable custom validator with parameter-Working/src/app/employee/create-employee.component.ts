import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators, AbstractControl } from '@angular/forms';
import { CustomValidators } from '../shared/custom.validators';

@Component({
  selector: 'app-create-employee',
  templateUrl: './create-employee.component.html',
  styleUrls: ['./create-employee.component.css']
})
export class CreateEmployeeComponent implements OnInit {
  employeeForm: FormGroup;

  constructor(private fb: FormBuilder) { }
  ngOnInit() {
    this.employeeForm = this.fb.group({
      fullName: ['', [Validators.required,
      Validators.minLength(2), Validators.maxLength(10)]],
      //email: ['', [Validators.required, Validators.email,  CustomValidators.emailDomain]],// Email domain validation without Parameter
      //email: ['', [Validators.required, Validators.email, emailDomainParam('gmail.com')]],// Email domain validation with Parameter
      email: ['', [Validators.required, Validators.email, CustomValidators.emailDomainParam('gmail.com')]],// Reusable Custom Validator example
      contactPreference: ['email'],
      phone: [''],
      skills: this.fb.group({
        skillName: ['', Validators.required],
        experienceInYears: ['', Validators.required],
        proficiency: ['', Validators.required]
      }),
    });
    ////Using FormGroup
    //  this.employeeForm = new FormGroup({
    //         fullName: new FormControl(),
    //         email: new FormControl(),
    //         // Create skills form group
    //         skills: new FormGroup({
    //           skillName: new FormControl(),
    //           experienceInYears: new FormControl(),
    //           proficiency: new FormControl()
    //         })
    //       }); 
  
    // Subscribe to valueChanges observable
    this.employeeForm.valueChanges.subscribe((data)=>{
        this.logValidationErrors(this.employeeForm);
    });
    this.employeeForm.get('contactPreference')
                 .valueChanges.subscribe((data: string) => {
        this.onContactPrefernceChange(data);
    });
  }
  formErrors = {
    'fullName': '',
    'email': '',
    'phone':'',
    'skillName': '',
    'experienceInYears': '',
    'proficiency': ''
  };
  validationMessages = {
    'fullName': {
      'required': 'Full Name is required.',
      'minlength': 'Full Name must be greater than 2 characters.',
      'maxlength': 'Full Name must be less than 10 characters.'
    },
    'email': {
      'required': 'Email is required.',
      'email': 'It is not a valid Email.',
      'emailDomain': 'Email domian does not match.'
    },
    'phone': {
      'required': 'Phone number is required.',
    },
    'skillName': {
      'required': 'Skill Name is required.',
    },
    'experienceInYears': {
      'required': 'Experience is required.',
    },
    'proficiency': {
      'required': 'Proficiency is required.',
    },
  };
  logValidationErrors(group: FormGroup = this.employeeForm): void { 
    Object.keys(group.controls).forEach((key: string) => { 
      const abstractControl = group.get(key); 
      if (abstractControl instanceof FormGroup) {
        this.logValidationErrors(abstractControl); 
      } else { 
        this.formErrors[key] = '';
        if (abstractControl && !abstractControl.valid && ( abstractControl.touched || abstractControl.dirty)) { 
          const messages = this.validationMessages[key]; 
          for (const errorKey in abstractControl.errors) {
            if (errorKey) {
              this.formErrors[key] += messages[errorKey] + ' ';
            }
          }
        }
      }
    });
    console.log("Test : ", this.formErrors)
  }
  //Dynamically add the validator on runtime
  onContactPrefernceChange(selectedValue: string) {
    const phoneFormControl = this.employeeForm.get('phone');
    if (selectedValue === 'phone') {
      phoneFormControl.setValidators(Validators.required);
    } else {
      phoneFormControl.clearValidators();
    }
    phoneFormControl.updateValueAndValidity();
  }
  onLoadDataClick(): void {
    //this.logValidationErrors(this.employeeForm);
    console.log(this.formErrors);
  }
  onSubmit(): void {
    console.log(this.employeeForm.value);
  }
}  
//As the below codes are reusable move to a separate class.  
// function emailDomain(control: AbstractControl): { [key: string]: any } | null {
//       const email: string = control.value;
//       const domain = email.substring(email.lastIndexOf('@') + 1);
//       if (email === '' || domain.toLowerCase() === 'yahoo.com') {
//         return null;
//       } else {
//         return { 'emailDomain': true };
//       }
// }
// function emailDomainParam(domainName: string) {
//       return (control: AbstractControl): { [key: string]: any } | null => {
//         const email: string = control.value;
//         const domain = email.substring(email.lastIndexOf('@') + 1);
//         if (email === '' || domain.toLowerCase() === domainName.toLowerCase()) {
//           return null;
//         } else {
//           return { 'emailDomain': true };
//         }
//       };
// }
       