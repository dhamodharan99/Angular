(To get the employees details for db.json)
Execute the following command to start the server
json-server --watch db.json